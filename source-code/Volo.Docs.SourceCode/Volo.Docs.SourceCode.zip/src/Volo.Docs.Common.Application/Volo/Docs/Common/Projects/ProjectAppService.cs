using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Caching.Distributed;
using Volo.Abp.Application.Dtos;
using Volo.Abp.Caching;
using Volo.Abp.Data;
using Volo.Abp.Threading;
using Volo.Docs.Caching;
using Volo.Docs.Documents;
using Volo.Docs.Projects;

namespace Volo.Docs.Common.Projects
{
    public class ProjectAppService : DocsCommonAppServiceBase, IProjectAppService
    {
        private readonly IProjectRepository _projectRepository;
        private readonly IDistributedCache<List<VersionInfo>> _versionCache;
        private readonly IDocumentSourceFactory _documentSource;
        protected IDistributedCache<LanguageConfig> LanguageCache { get; }

        private readonly SemaphoreSlim _syncSemaphore = new SemaphoreSlim(1, 1);

        public ProjectAppService(
            IProjectRepository projectRepository,
            IDistributedCache<List<VersionInfo>> versionCache,
            IDocumentSourceFactory documentSource,
            IDistributedCache<LanguageConfig> languageCache)
        {
            _projectRepository = projectRepository;
            _versionCache = versionCache;
            _documentSource = documentSource;
            LanguageCache = languageCache;
        }

        public virtual async Task<ListResultDto<ProjectDto>> GetListAsync()
        {
            var projects = await _projectRepository.GetListAsync();

            var projectDtos = new List<ProjectDto>(
                ObjectMapper.Map<List<Project>, List<ProjectDto>>(projects)
            );

            return new ListResultDto<ProjectDto>(
                projectDtos.Select(p => HidePrivateProperties(p)).ToList()
            );
        }

        public virtual async Task<ProjectDto> GetAsync(string shortName)
        {
            var project = await _projectRepository.GetByShortNameAsync(shortName);

            var projectDto = ObjectMapper.Map<Project, ProjectDto>(project);

            return HidePrivateProperties(projectDto);
        }

        public virtual async Task<ListResultDto<VersionInfoDto>> GetVersionsAsync(string shortName)
        {
            var project = await _projectRepository.GetByShortNameAsync(shortName);
            using (await _syncSemaphore.LockAsync())
            {
                var versions = await _versionCache.GetAsync(CacheKeyGenerator.GenerateProjectVersionsCacheKey(project));
                if (versions.IsNullOrEmpty())
                {
                    versions = await GetVersionsAsync(project);
                    if (!versions.IsNullOrEmpty())
                    {
                        await _versionCache.SetAsync(
                            CacheKeyGenerator.GenerateProjectVersionsCacheKey(project),
                            versions,
                            new DistributedCacheEntryOptions
                            {
                                //TODO: Configurable?
                                AbsoluteExpirationRelativeToNow = TimeSpan.FromHours(12),
                                SlidingExpiration = TimeSpan.FromMinutes(60)
                            }
                        );
                    }
                }

                return new ListResultDto<VersionInfoDto>(
                    ObjectMapper.Map<List<VersionInfo>, List<VersionInfoDto>>(versions)
                );
            }
        }

        protected virtual async Task<List<VersionInfo>> GetVersionsAsync(Project project)
        {
            var store = _documentSource.Create(project.DocumentStoreType);
            var versions = await store.GetVersionsAsync(project);

            if (!versions.Any())
            {
                return versions;
            }

            if (!project.MinimumVersion.IsNullOrEmpty())
            {
                var minVersionIndex = versions.FindIndex(v => v.Name == project.MinimumVersion);
                if (minVersionIndex > -1)
                {
                    versions = versions.GetRange(0, minVersionIndex + 1);
                }
            }

            return versions;
        }

        public virtual async Task<LanguageConfig> GetLanguageListAsync(string shortName, string version)
        {
            return await GetLanguageListInternalAsync(shortName, version);
        }

        public virtual async Task<string> GetDefaultLanguageCodeAsync(string shortName, string version)
        {
            var languageList = await GetLanguageListInternalAsync(shortName, version);

            return (languageList.Languages.FirstOrDefault(l => l.IsDefault) ?? languageList.Languages.First()).Code;
        }

        private async Task<LanguageConfig> GetLanguageListInternalAsync(string shortName, string version)
        {
            var project = await _projectRepository.GetByShortNameAsync(shortName);
            var store = _documentSource.Create(project.DocumentStoreType);

            version = GetProjectVersionPrefixIfExist(project) + version;

            async Task<LanguageConfig> GetLanguagesAsync()
            {
                return await store.GetLanguageListAsync(project, version);
            }

            return await LanguageCache.GetOrAddAsync(
                CacheKeyGenerator.GenerateProjectLanguageCacheKey(project),
                GetLanguagesAsync,
                () => new DistributedCacheEntryOptions
                {
                    AbsoluteExpirationRelativeToNow = TimeSpan.FromHours(24)
                }
            );
        }

        private string GetProjectVersionPrefixIfExist(Project project)
        {
            if (GetGithubVersionProviderSource(project) != GithubVersionProviderSource.Branches)
            {
                return string.Empty;
            }

            return project.GetProperty<string>("VersionBranchPrefix");
        }

        private GithubVersionProviderSource GetGithubVersionProviderSource(Project project)
        {
            return project.HasProperty("GithubVersionProviderSource")
                ? project.GetProperty<GithubVersionProviderSource>("GithubVersionProviderSource")
                : GithubVersionProviderSource.Releases;
        }

        private ProjectDto HidePrivateProperties(ProjectDto project)
        {
            if (project.HasProperty("GitHubAccessToken"))
            {
                project.SetProperty("GitHubAccessToken", null);
            }

            if (project.HasProperty("GitHubUserAgent"))
            {
                project.SetProperty("GitHubUserAgent", null);
            }

            return project;
        }
    }
}
